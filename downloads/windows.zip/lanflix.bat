@echo off
start chrome --app=http://192.168.1.71:8000 2>nul
if errorlevel 1 start msedge --app=http://192.168.1.71:8000 2>nul
if errorlevel 1 start http://192.168.1.71:8000
