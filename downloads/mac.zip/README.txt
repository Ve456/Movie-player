Lan flix desktop launcher — macOS

This opens Lan flix in its own window using a browser already on your
device, with no address bar or tabs. It is a small launcher script, not an
installer or a compiled app.

It points at: http://192.168.1.71:8000
If your server's IP address ever changes, restart the Lan flix server once
to regenerate these downloads with the new address.

Double-click lanflix.command to launch. The first time, you may need to right-click it, choose Open, and confirm — macOS blocks unsigned scripts by default (System Settings -> Privacy & Security also has an "Open Anyway" option if needed).
